# WEDE5020 Part 2 — Sweet Crumbs Bakery

**Student Name:** Mukundi Mkdau  
**Student Number:** ST10533129  
**Campus:** Rosebank College  
**Module:** WEDE5020 — Web Development (Introduction)  
**Part:** 2 — Designing the Visuals: CSS Styling and Responsive Design

## Project overview
Sweet Crumbs Bakery is the fictional organisation selected in Part 1. It specialises in freshly baked bread, cakes, cupcakes, pastries, cookies and customised celebration cakes. The Part 2 website focuses on CSS styling, responsive design, interaction states and responsive images.

## Part 1 feedback / improvements
The project keeps the five-page structure from Part 1 and improves consistency by using one external stylesheet across all pages, clearer responsive behaviour, accessible focus states, responsive images and documented changes.

## Pages
- Home — `index.html`
- About — `about.html`
- Products — `products.html`
- Enquiry — `enquiry.html`
- Contact — `contact.html`

## Part 2 implementation
### External CSS
All five pages link to `css/style.css`. The stylesheet contains reusable variables, reset rules, typography, layout and visual styling.

### Typography
The project uses `rem`, `clamp()`, font weights, line-height and letter-spacing to create a scalable hierarchy.

### Layout
CSS Grid is used for the hero, cards, products and two-column sections. Flexbox is used for navigation, buttons and footer.

### Visual styles
The site uses a cream, brown, white and soft-gold palette, borders, rounded corners, shadows and hover/focus/active states.

### Responsive design
Breakpoints:
- Tablet: `62.5rem` / 1000px
- Mobile: `43.75rem` / 700px

Multi-column layouts reduce to fewer columns and then one column. Mobile navigation becomes a toggle menu.

### Relative units
The CSS uses `%`, `rem`, `vw`, `clamp()`, `min()` and scalable spacing instead of relying only on fixed pixel values.

### Responsive images
The home page uses `<picture>`, `<source>`, `srcset` and `sizes` with small, medium and large SVG assets.

## Browser testing
Use browser Developer Tools and test approximately:
- Desktop: 1440px
- Tablet: 900px
- Mobile: 390px

Save genuine screenshots in `screenshots/` and add them to GitHub. Suggested names:
- `desktop-home.png`
- `tablet-home.png`
- `mobile-home.png`

## Changelog — 15 September 2026
- Updated all five HTML pages to use a shared external stylesheet.
- Added CSS reset and reusable CSS custom properties.
- Added responsive Grid and Flexbox layouts.
- Added scalable typography using `rem` and `clamp()`.
- Added hover, focus-visible and active states.
- Added responsive navigation using JavaScript.
- Added responsive images using `picture`, `srcset` and `sizes`.
- Added enquiry form validation and success feedback.
- Updated README documentation for Part 2.
- Added submission and testing guidance.

## Suggested Git commits
1. `Update HTML structure and navigation`
2. `Add shared responsive CSS stylesheet`
3. `Add responsive images with picture and srcset`
4. `Add mobile navigation and form validation`
5. `Update README with Part 2 changelog and testing`

## References
- MDN Web Docs. (2026). HTML, CSS and JavaScript documentation. https://developer.mozilla.org/
- W3Schools. (2026). HTML, CSS and JavaScript tutorials. https://www.w3schools.com/
- Google Fonts. (2026). Browse Fonts. https://fonts.google.com/
- Font Awesome. (2026). Icons for web projects. https://fontawesome.com/
- Unsplash. (2026). Free images. https://unsplash.com/
- Pexels. (2026). Free stock photos. https://www.pexels.com/
- GitHub Docs. (2026). GitHub documentation. https://docs.github.com/

## Submission checklist
- [ ] Replace/check student information.
- [ ] Open and test all five pages.
- [ ] Test desktop, tablet and mobile in Developer Tools.
- [ ] Add genuine responsive screenshots to `screenshots/`.
- [ ] Commit the changes using descriptive messages.
- [ ] Push the project to the existing GitHub repository.
- [ ] Confirm the repository is accessible.
- [ ] Submit the GitHub link on the LMS.

**Important:** the screenshot files must be genuine screenshots from browser testing; this package does not fabricate screenshot evidence.
